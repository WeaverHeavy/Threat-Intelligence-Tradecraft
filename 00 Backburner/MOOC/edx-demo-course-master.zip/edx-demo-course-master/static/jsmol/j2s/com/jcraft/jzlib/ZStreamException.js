Clazz.declarePackage ("com.jcraft.jzlib");
Clazz.load (["java.io.IOException"], "com.jcraft.jzlib.ZStreamException", null, function () {
c$ = Clazz.declareType (com.jcraft.jzlib, "ZStreamException", java.io.IOException);
});
