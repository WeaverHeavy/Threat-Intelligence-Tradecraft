Clazz.declarePackage ("com.jcraft.jzlib");
Clazz.load (["java.io.IOException"], "com.jcraft.jzlib.GZIPException", null, function () {
c$ = Clazz.declareType (com.jcraft.jzlib, "GZIPException", java.io.IOException);
});
