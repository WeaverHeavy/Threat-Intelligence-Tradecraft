$_L(["java.util.IllegalFormatException"],"java.util.IllegalFormatWidthException",null,function(){
c$=$_C(function(){
this.w=0;
$_Z(this,arguments);
},java.util,"IllegalFormatWidthException",java.util.IllegalFormatException);
$_K(c$,
function(w){
$_R(this,java.util.IllegalFormatWidthException,[]);
this.w=w;
},"~N");
$_M(c$,"getWidth",
function(){
return this.w;
});
$_V(c$,"getMessage",
function(){
return String.valueOf(this.w);
});
});
