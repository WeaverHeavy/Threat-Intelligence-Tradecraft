Clazz.declarePackage ("java.net");
Clazz.load (["java.io.IOException"], "java.net.MalformedURLException", null, function () {
c$ = Clazz.declareType (java.net, "MalformedURLException", java.io.IOException);
Clazz.makeConstructor (c$, 
function () {
Clazz.superConstructor (this, java.net.MalformedURLException, []);
});
});
